#encoding:utf-8
'抓取ptt電影版的網頁原始碼'
import urllib.request as req
url="https://www.ptt.cc/bbs/movie/index.html"

#建立一個request物件，附加request healder的資訊 
#開chrome->右上角三個點->更多工具->開發人員工具->Network->重新整理->通常是第一個選項
request=req.Request(url,headers={
    "User-Agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36"
})
with req.urlopen(request) as ptt:
    data=ptt.read().decode("utf-8")

"解析原始碼取得每一篇文章的標題"
import bs4
root=bs4.BeautifulSoup(data,"html.parser")
"找到有這些標籤的其中一個"
titles=root.find("div",class_="title")#尋找class="title"的div標籤

print(titles)#a裡面的字元 
"找到所有有這個標籤的"
titles=root.find_all("div",class_="title")
with open("data.txt",mode="w") as data:
    for title in titles:
        if title.a!=None:#如果標題包含a標籤,印出來
            data.write(title.a.string+"\n")