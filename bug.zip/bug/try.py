#encoding:utf-8
import requests
url='https://invest.cnyes.com/twstock/TWS/2330'
import requests

try:
    response = requests.get(url)
    content = response.content
    print(content)
except Exception as e:
    print("Error: ", e)

    print("Error: ", e)
